import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Search, Menu, X, Film, Heart, Bookmark, User, Home } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm)}`);
      setSearchTerm('');
      setIsMenuOpen(false);
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-dark-900/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container-custom py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Film className="text-primary-500 h-7 w-7" />
            <span className="text-2xl font-bold text-white">Cinema<span className="text-primary-500">Hub</span></span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}>
              Home
            </Link>
            <Link to="/category/trending" className={`nav-link ${location.pathname === '/category/trending' ? 'active' : ''}`}>
              Trending
            </Link>
            <Link to="/category/upcoming" className={`nav-link ${location.pathname === '/category/upcoming' ? 'active' : ''}`}>
              Upcoming
            </Link>
            <Link to="/category/top-rated" className={`nav-link ${location.pathname === '/category/top-rated' ? 'active' : ''}`}>
              Top Rated
            </Link>
          </nav>

          {/* Search Form - Desktop */}
          <div className="hidden md:block relative">
            <form onSubmit={handleSearch} className="flex items-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search movies..."
                  className="search-input"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <button 
                type="submit" 
                className="ml-2 bg-primary-500 hover:bg-primary-600 text-dark-900 p-2 rounded-full transition-colors"
              >
                <Search className="h-5 w-5" />
              </button>
            </form>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white p-2 focus:outline-none"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`md:hidden fixed inset-0 z-50 bg-dark-900/95 backdrop-blur-md transform transition-transform duration-300 ease-in-out ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full pt-16 pb-6 px-6">
          {/* Mobile Search */}
          <form onSubmit={handleSearch} className="mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search movies..."
                className="search-input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button 
              type="submit" 
              className="mt-2 w-full bg-primary-500 hover:bg-primary-600 text-dark-900 py-2 rounded-md transition-colors"
            >
              Search
            </button>
          </form>

          {/* Mobile Nav Links */}
          <div className="flex flex-col space-y-6 text-lg">
            <Link 
              to="/" 
              className="flex items-center space-x-3"
              onClick={() => setIsMenuOpen(false)}
            >
              <Home className="h-5 w-5 text-primary-500" />
              <span>Home</span>
            </Link>
            <Link 
              to="/category/trending" 
              className="flex items-center space-x-3"
              onClick={() => setIsMenuOpen(false)}
            >
              <Film className="h-5 w-5 text-primary-500" />
              <span>Trending</span>
            </Link>
            <Link 
              to="/category/upcoming" 
              className="flex items-center space-x-3"
              onClick={() => setIsMenuOpen(false)}
            >
              <Bookmark className="h-5 w-5 text-primary-500" />
              <span>Upcoming</span>
            </Link>
            <Link 
              to="/category/top-rated" 
              className="flex items-center space-x-3"
              onClick={() => setIsMenuOpen(false)}
            >
              <Heart className="h-5 w-5 text-primary-500" />
              <span>Top Rated</span>
            </Link>
          </div>

          <div className="mt-auto">
            <div className="flex items-center justify-center space-x-3 mb-3">
              <User className="h-5 w-5 text-primary-500" />
              <span>Guest User</span>
            </div>
            <p className="text-center text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} CinemaHub
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;