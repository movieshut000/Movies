import { motion } from 'framer-motion';
import { Cast } from '../types/movie';

interface CastMemberProps {
  cast: Cast;
  index: number;
}

const CastMember = ({ cast, index }: CastMemberProps) => {
  return (
    <motion.div 
      className="flex flex-col items-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.3 }}
    >
      <div className="w-20 h-20 md:w-24 md:h-24 rounded-full overflow-hidden mb-2 border-2 border-dark-600">
        <img 
          src={cast.image} 
          alt={cast.name} 
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <h4 className="text-sm font-medium text-white text-center line-clamp-1">{cast.name}</h4>
      <p className="text-xs text-gray-400 text-center line-clamp-1">{cast.character}</p>
    </motion.div>
  );
};

export default CastMember;