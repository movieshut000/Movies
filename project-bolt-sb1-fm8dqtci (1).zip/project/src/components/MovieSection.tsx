import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import MovieCard from './MovieCard';
import { Movie } from '../types/movie';

interface MovieSectionProps {
  title: string;
  movies: Movie[];
  viewAllLink: string;
}

const MovieSection = ({ title, movies, viewAllLink }: MovieSectionProps) => {
  const [startIndex, setStartIndex] = useState(0);
  
  // Number of movies to show based on screen size
  const getVisibleCount = () => {
    if (typeof window === 'undefined') return 5;
    if (window.innerWidth < 640) return 2; // sm
    if (window.innerWidth < 768) return 3; // md
    if (window.innerWidth < 1024) return 4; // lg
    return 5; // xl and up
  };

  const visibleCount = getVisibleCount();
  const visibleMovies = movies.slice(startIndex, startIndex + visibleCount);
  const canScrollLeft = startIndex > 0;
  const canScrollRight = startIndex + visibleCount < movies.length;

  const scrollLeft = () => {
    if (canScrollLeft) {
      setStartIndex(Math.max(0, startIndex - 1));
    }
  };

  const scrollRight = () => {
    if (canScrollRight) {
      setStartIndex(Math.min(movies.length - visibleCount, startIndex + 1));
    }
  };

  return (
    <section className="mt-16">
      <div className="container-custom">
        <div className="flex items-center justify-between mb-6">
          <h2 className="section-title">{title}</h2>
          <Link 
            to={viewAllLink}
            className="text-primary-500 hover:text-primary-400 flex items-center transition-colors duration-300"
          >
            View All
            <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        
        <div className="relative">
          {/* Navigation Buttons */}
          {canScrollLeft && (
            <button 
              onClick={scrollLeft}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-dark-800/80 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-primary-500 transition-colors duration-300 -ml-5"
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          )}
          
          {canScrollRight && (
            <button 
              onClick={scrollRight}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-dark-800/80 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-primary-500 transition-colors duration-300 -mr-5"
              aria-label="Scroll right"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          )}
          
          {/* Movie Grid */}
          <motion.div 
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6"
          >
            {visibleMovies.map((movie, index) => (
              <MovieCard 
                key={movie.id} 
                movie={movie} 
                priority={index < 2}
              />
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default MovieSection;