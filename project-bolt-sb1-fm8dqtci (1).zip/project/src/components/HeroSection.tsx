import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Play, Info } from 'lucide-react';
import { movies } from '../data/movies';

const HeroSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const navigate = useNavigate();
  
  // Get trending movies for the hero section
  const heroMovies = movies.filter(movie => movie.trending).slice(0, 5);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % heroMovies.length);
    }, 8000);

    return () => clearInterval(interval);
  }, [heroMovies.length]);

  const currentMovie = heroMovies[currentIndex];

  return (
    <div className="relative w-full h-[80vh] md:h-[90vh] overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-opacity duration-1000"
        style={{ 
          backgroundImage: `url(${currentMovie.backdrop})`,
          opacity: 0.6
        }}
      />
      
      {/* Gradient Overlay */}
      <div 
        className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/80 to-transparent"
      />

      {/* Content */}
      <div className="container-custom relative z-10 h-full flex flex-col justify-end pb-20">
        <motion.div
          key={currentMovie.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl"
        >
          {/* Title */}
          <h1 className="text-4xl md:text-6xl font-bold mb-3 text-white">{currentMovie.title}</h1>
          
          {/* Meta */}
          <div className="flex flex-wrap items-center text-sm md:text-base mb-4 text-gray-300">
            <span className="bg-primary-500 text-dark-900 py-1 px-2 rounded mr-3">
              {currentMovie.rating} / 10
            </span>
            <span className="mr-3">{currentMovie.year}</span>
            <span className="mr-3">{currentMovie.duration} min</span>
            <span>{currentMovie.genres.join(', ')}</span>
          </div>
          
          {/* Description */}
          <p className="text-gray-300 mb-8 text-base md:text-lg line-clamp-3">
            {currentMovie.description}
          </p>
          
          {/* Buttons */}
          <div className="flex flex-wrap gap-4">
            <button className="btn-primary flex items-center gap-2">
              <Play className="h-5 w-5" />
              Watch Trailer
            </button>
            <button 
              className="btn-secondary flex items-center gap-2"
              onClick={() => navigate(`/movie/${currentMovie.id}`)}
            >
              <Info className="h-5 w-5" />
              More Info
            </button>
          </div>
        </motion.div>
      </div>

      {/* Indicator Dots */}
      <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2 z-20">
        {heroMovies.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === currentIndex ? 'bg-primary-500 w-6' : 'bg-gray-500 hover:bg-gray-400'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroSection;