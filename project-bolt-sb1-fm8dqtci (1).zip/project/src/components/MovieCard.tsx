import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Clock, Calendar, Play } from 'lucide-react';
import { Movie } from '../types/movie';

interface MovieCardProps {
  movie: Movie;
  priority?: boolean;
}

const MovieCard = ({ movie, priority = false }: MovieCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/movie/${movie.id}`);
  };

  return (
    <motion.div
      className="movie-card group cursor-pointer"
      whileHover={{ y: -5 }}
      initial={priority ? { opacity: 1 } : { opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Poster Image */}
      <div className="aspect-[2/3] relative rounded-lg overflow-hidden">
        <img 
          src={movie.poster} 
          alt={movie.title}
          loading={priority ? "eager" : "lazy"}
          className="w-full h-full object-cover transition-transform duration-500 will-change-transform"
          style={{
            transform: isHovered ? 'scale(1.05)' : 'scale(1)'
          }}
        />
        
        {/* Overlay Gradient */}
        <div className="movie-card-overlay"></div>
        
        {/* Play button on hover */}
        <div 
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="w-12 h-12 rounded-full bg-primary-500 flex items-center justify-center">
            <Play className="h-6 w-6 text-dark-900" />
          </div>
        </div>

        {/* Movie Info */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="text-lg font-semibold line-clamp-1 mb-2">{movie.title}</h3>
          
          <div className="flex items-center text-xs text-gray-300 space-x-3">
            <div className="flex items-center">
              <Star className="h-3 w-3 text-primary-500 mr-1" />
              <span>{movie.rating}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-3 w-3 text-gray-400 mr-1" />
              <span>{movie.duration} min</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-3 w-3 text-gray-400 mr-1" />
              <span>{movie.year}</span>
            </div>
          </div>
          
          {/* Genres - visible on hover */}
          <div 
            className={`mt-2 transition-all duration-300 ${
              isHovered ? 'opacity-100 max-h-16' : 'opacity-0 max-h-0 overflow-hidden'
            }`}
          >
            <div className="flex flex-wrap gap-1">
              {movie.genres.slice(0, 3).map((genre, index) => (
                <span key={index} className="genre-badge">
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default MovieCard;