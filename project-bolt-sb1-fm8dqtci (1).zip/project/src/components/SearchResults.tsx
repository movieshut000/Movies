import { motion } from 'framer-motion';
import MovieCard from './MovieCard';
import { Movie } from '../types/movie';

interface SearchResultsProps {
  movies: Movie[];
  query: string;
}

const SearchResults = ({ movies, query }: SearchResultsProps) => {
  if (movies.length === 0) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center text-center p-8">
        <h2 className="text-2xl font-bold mb-4">No results found</h2>
        <p className="text-gray-400 max-w-md mb-6">
          We couldn't find any movies matching "{query}". Try different keywords or browse our categories.
        </p>
        <img 
          src="https://images.pexels.com/photos/33129/popcorn-movie-party-entertainment.jpg?auto=compress&cs=tinysrgb&w=600" 
          alt="No results"
          className="w-40 h-40 object-cover rounded-full opacity-50"
        />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6"
    >
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </motion.div>
  );
};

export default SearchResults;