import { Link } from 'react-router-dom';
import { Film, Instagram, Twitter, Facebook, Github } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-dark-800 border-t border-dark-600 mt-20">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <Film className="text-primary-500 h-6 w-6" />
              <span className="text-xl font-bold text-white">Cinema<span className="text-primary-500">Hub</span></span>
            </Link>
            <p className="text-gray-400 text-sm">
              Discover amazing movies and explore the world of cinema with our curated collection.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Github className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/category/trending" className="text-gray-400 hover:text-white transition-colors">Trending</Link>
              </li>
              <li>
                <Link to="/category/upcoming" className="text-gray-400 hover:text-white transition-colors">Upcoming</Link>
              </li>
              <li>
                <Link to="/category/top-rated" className="text-gray-400 hover:text-white transition-colors">Top Rated</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Genres</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/search?genre=action" className="text-gray-400 hover:text-white transition-colors">Action</Link>
              </li>
              <li>
                <Link to="/search?genre=adventure" className="text-gray-400 hover:text-white transition-colors">Adventure</Link>
              </li>
              <li>
                <Link to="/search?genre=comedy" className="text-gray-400 hover:text-white transition-colors">Comedy</Link>
              </li>
              <li>
                <Link to="/search?genre=drama" className="text-gray-400 hover:text-white transition-colors">Drama</Link>
              </li>
              <li>
                <Link to="/search?genre=sci-fi" className="text-gray-400 hover:text-white transition-colors">Sci-Fi</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">Help Center</Link>
              </li>
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</Link>
              </li>
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link>
              </li>
              <li>
                <Link to="#" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-dark-600 mt-8 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} CinemaHub. All rights reserved.</p>
          <p className="mt-1">This website is for demo purposes only. All content is used for demonstrative purposes.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;