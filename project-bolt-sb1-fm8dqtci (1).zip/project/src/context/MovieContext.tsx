import { createContext, useContext, useState, ReactNode } from 'react';
import { Movie } from '../types/movie';

interface MovieContextType {
  favoriteMovies: number[];
  watchlist: number[];
  addToFavorites: (movieId: number) => void;
  removeFromFavorites: (movieId: number) => void;
  addToWatchlist: (movieId: number) => void;
  removeFromWatchlist: (movieId: number) => void;
  isFavorite: (movieId: number) => boolean;
  isInWatchlist: (movieId: number) => boolean;
}

const MovieContext = createContext<MovieContextType | undefined>(undefined);

export const MovieProvider = ({ children }: { children: ReactNode }) => {
  const [favoriteMovies, setFavoriteMovies] = useState<number[]>([]);
  const [watchlist, setWatchlist] = useState<number[]>([]);

  const addToFavorites = (movieId: number) => {
    setFavoriteMovies(prev => [...prev, movieId]);
  };

  const removeFromFavorites = (movieId: number) => {
    setFavoriteMovies(prev => prev.filter(id => id !== movieId));
  };

  const addToWatchlist = (movieId: number) => {
    setWatchlist(prev => [...prev, movieId]);
  };

  const removeFromWatchlist = (movieId: number) => {
    setWatchlist(prev => prev.filter(id => id !== movieId));
  };

  const isFavorite = (movieId: number) => {
    return favoriteMovies.includes(movieId);
  };

  const isInWatchlist = (movieId: number) => {
    return watchlist.includes(movieId);
  };

  const value = {
    favoriteMovies,
    watchlist,
    addToFavorites,
    removeFromFavorites,
    addToWatchlist,
    removeFromWatchlist,
    isFavorite,
    isInWatchlist,
  };

  return <MovieContext.Provider value={value}>{children}</MovieContext.Provider>;
};

export const useMovieContext = () => {
  const context = useContext(MovieContext);
  if (context === undefined) {
    throw new Error('useMovieContext must be used within a MovieProvider');
  }
  return context;
};