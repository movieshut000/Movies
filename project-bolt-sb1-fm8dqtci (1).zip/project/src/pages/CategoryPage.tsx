import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { movies } from '../data/movies';
import MovieCard from '../components/MovieCard';
import { Movie } from '../types/movie';

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();
  const [categoryMovies, setCategoryMovies] = useState<Movie[]>([]);
  const [categoryTitle, setCategoryTitle] = useState('');
  
  useEffect(() => {
    let filteredMovies: Movie[] = [];
    let title = '';
    
    // Filter movies based on category
    switch (category) {
      case 'trending':
        filteredMovies = movies.filter(movie => movie.trending);
        title = 'Trending Movies';
        break;
      case 'upcoming':
        filteredMovies = movies.filter(movie => movie.upcoming);
        title = 'Upcoming Movies';
        break;
      case 'top-rated':
        filteredMovies = movies.filter(movie => movie.rating >= 8.5);
        title = 'Top Rated Movies';
        break;
      default:
        filteredMovies = movies;
        title = 'All Movies';
    }
    
    setCategoryMovies(filteredMovies);
    setCategoryTitle(title);
    
    // Scroll to top
    window.scrollTo(0, 0);
  }, [category]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-24 md:pt-32"
    >
      <div className="container-custom">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{categoryTitle}</h1>
          <p className="text-gray-400">
            {categoryMovies.length} movies available
          </p>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-16">
          {categoryMovies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default CategoryPage;