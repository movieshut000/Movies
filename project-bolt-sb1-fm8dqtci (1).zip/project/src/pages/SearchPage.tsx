import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search as SearchIcon } from 'lucide-react';
import { movies } from '../data/movies';
import SearchResults from '../components/SearchResults';
import { Movie } from '../types/movie';

const SearchPage = () => {
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Movie[]>([]);
  
  // Parse query parameters
  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const query = queryParams.get('q') || '';
    const genre = queryParams.get('genre') || '';
    
    setSearchQuery(query || genre);
    
    // Filter movies based on query or genre
    let filteredMovies: Movie[] = [];
    
    if (query) {
      // Search by movie title
      filteredMovies = movies.filter(movie => 
        movie.title.toLowerCase().includes(query.toLowerCase())
      );
    } else if (genre) {
      // Filter by genre
      filteredMovies = movies.filter(movie => 
        movie.genres.map(g => g.toLowerCase()).includes(genre.toLowerCase())
      );
    }
    
    setSearchResults(filteredMovies);
    
    // Scroll to top
    window.scrollTo(0, 0);
  }, [location.search]);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (searchQuery.trim()) {
      // Filter movies by title
      const results = movies.filter(movie => 
        movie.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
      
      setSearchResults(results);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-24 md:pt-32"
    >
      <div className="container-custom">
        <div className="max-w-2xl mx-auto mb-12">
          <form onSubmit={handleSearch} className="relative">
            <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search for movies..."
              className="w-full bg-dark-700 text-white border border-dark-600 rounded-full py-3 px-12 focus:outline-none focus:ring-2 focus:ring-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit" 
              className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-dark-900 p-1.5 rounded-full transition-colors"
            >
              <SearchIcon className="h-4 w-4" />
            </button>
          </form>
        </div>
        
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">
            {searchResults.length > 0 
              ? `Search Results for "${searchQuery}"`
              : `No Results for "${searchQuery}"`
            }
          </h1>
          <p className="text-gray-400">
            {searchResults.length > 0 
              ? `Found ${searchResults.length} movies matching your search`
              : 'Try different keywords or browse our categories'
            }
          </p>
        </div>
        
        <div className="mb-16">
          <SearchResults movies={searchResults} query={searchQuery} />
        </div>
      </div>
    </motion.div>
  );
};

export default SearchPage;