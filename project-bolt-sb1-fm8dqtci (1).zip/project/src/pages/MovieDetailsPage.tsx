import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Clock, Calendar, Play, ChevronLeft } from 'lucide-react';
import { movies } from '../data/movies';
import MovieSection from '../components/MovieSection';
import CastMember from '../components/CastMember';
import { Movie } from '../types/movie';

const MovieDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [movie, setMovie] = useState<Movie | null>(null);
  
  useEffect(() => {
    // Find the movie by id
    const foundMovie = movies.find(m => m.id === parseInt(id || '0'));
    
    if (foundMovie) {
      setMovie(foundMovie);
    } else {
      // Redirect to 404 or home if movie not found
      navigate('/');
    }
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
  }, [id, navigate]);
  
  if (!movie) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  // Get similar movies based on genres
  const similarMovies = movies
    .filter(m => 
      m.id !== movie.id && 
      m.genres.some(genre => movie.genres.includes(genre))
    )
    .slice(0, 10);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Back Button */}
      <div className="container-custom pt-20 md:pt-24">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
        >
          <ChevronLeft className="h-5 w-5 mr-1" />
          Back
        </button>
      </div>
      
      {/* Hero Section with Backdrop */}
      <div className="relative w-full">
        {/* Backdrop Image */}
        <div className="w-full h-[50vh] md:h-[60vh]">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${movie.backdrop})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/80 to-transparent" />
        </div>
        
        {/* Movie Details */}
        <div className="container-custom relative z-10 -mt-40 md:-mt-64">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Poster */}
            <motion.div 
              className="w-48 md:w-64 mx-auto md:mx-0 shrink-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <img 
                src={movie.poster} 
                alt={movie.title}
                className="w-full h-auto rounded-lg shadow-2xl"
              />
            </motion.div>
            
            {/* Details */}
            <motion.div 
              className="flex-1"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h1 className="text-3xl md:text-5xl font-bold mb-3">{movie.title}</h1>
              
              {/* Meta Information */}
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <div className="flex items-center bg-primary-500 text-dark-900 px-2 py-1 rounded">
                  <Star className="h-4 w-4 mr-1" />
                  <span className="font-bold">{movie.rating}</span>
                  <span className="text-dark-800">/10</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Clock className="h-4 w-4 mr-1 text-gray-400" />
                  <span>{movie.duration} min</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                  <span>{movie.year}</span>
                </div>
              </div>
              
              {/* Genres */}
              <div className="mb-6">
                <div className="flex flex-wrap gap-2">
                  {movie.genres.map((genre, index) => (
                    <span key={index} className="bg-dark-600 px-3 py-1 rounded-full text-sm">
                      {genre}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Description */}
              <p className="text-gray-300 mb-8">
                {movie.description}
              </p>
              
              {/* Action Buttons */}
              <div className="flex flex-wrap gap-4 mb-8">
                <button className="btn-primary flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  Watch Trailer
                </button>
                <button className="btn-secondary flex items-center gap-2">
                  Add to Watchlist
                </button>
              </div>
              
              {/* Director */}
              <div className="mb-4">
                <span className="text-gray-400">Director: </span>
                <span className="font-medium">{movie.director}</span>
              </div>
              
              {/* Writer */}
              <div>
                <span className="text-gray-400">Writer: </span>
                <span className="font-medium">{movie.writer}</span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Cast Section */}
      <section className="mt-16">
        <div className="container-custom">
          <h2 className="section-title mb-8">Cast</h2>
          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-4">
            {movie.cast.map((cast, index) => (
              <CastMember key={index} cast={cast} index={index} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Similar Movies */}
      <MovieSection 
        title="Similar Movies" 
        movies={similarMovies} 
        viewAllLink={`/search?genre=${movie.genres[0]}`} 
      />
    </motion.div>
  );
};

export default MovieDetailsPage;