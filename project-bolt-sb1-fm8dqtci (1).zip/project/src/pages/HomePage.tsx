import { motion } from 'framer-motion';
import HeroSection from '../components/HeroSection';
import MovieSection from '../components/MovieSection';
import { movies } from '../data/movies';

const HomePage = () => {
  // Filter different movie categories
  const trendingMovies = movies.filter(movie => movie.trending);
  const upcomingMovies = movies.filter(movie => movie.upcoming);
  const topRatedMovies = movies.filter(movie => movie.rating >= 8.5);
  
  // Different genre sections
  const actionMovies = movies.filter(movie => movie.genres.includes('Action'));
  const sciFiMovies = movies.filter(movie => movie.genres.includes('Sci-Fi'));

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <HeroSection />
      
      <MovieSection 
        title="Trending Now" 
        movies={trendingMovies} 
        viewAllLink="/category/trending" 
      />
      
      <MovieSection 
        title="Upcoming Movies" 
        movies={upcomingMovies} 
        viewAllLink="/category/upcoming" 
      />
      
      <MovieSection 
        title="Top Rated" 
        movies={topRatedMovies} 
        viewAllLink="/category/top-rated" 
      />
      
      <MovieSection 
        title="Action Movies" 
        movies={actionMovies} 
        viewAllLink="/search?genre=action" 
      />
      
      <MovieSection 
        title="Sci-Fi Adventure" 
        movies={sciFiMovies} 
        viewAllLink="/search?genre=sci-fi" 
      />
    </motion.div>
  );
};

export default HomePage;