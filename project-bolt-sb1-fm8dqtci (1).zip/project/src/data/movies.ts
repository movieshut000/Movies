import { Movie } from '../types/movie';

export const movies: Movie[] = [
  {
    id: 1,
    title: 'Guardians of the Galaxy Vol. 3',
    description: 'Still reeling from the loss of Gamora, Peter Quill rallies his team to defend the universe and one of their own - a mission that could mean the end of the Guardians if not successful.',
    poster: 'https://images.pexels.com/photos/15165844/pexels-photo-15165844/free-photo-of-guardians-of-the-galaxy-vol-3-movie-poster.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/2510428/pexels-photo-2510428.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.0,
    year: 2023,
    duration: 150,
    genres: ['Action', 'Adventure', 'Comedy'],
    director: 'James Gunn',
    writer: 'James Gunn',
    cast: [
      {
        name: 'Chris Pratt',
        character: 'Peter Quill / Star-Lord',
        image: 'https://images.pexels.com/photos/1304647/pexels-photo-1304647.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Zoe Saldana',
        character: 'Gamora',
        image: 'https://images.pexels.com/photos/2861823/pexels-photo-2861823.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Dave Bautista',
        character: 'Drax',
        image: 'https://images.pexels.com/photos/834863/pexels-photo-834863.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Bradley Cooper',
        character: 'Rocket (voice)',
        image: 'https://images.pexels.com/photos/2286452/pexels-photo-2286452.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Vin Diesel',
        character: 'Groot (voice)',
        image: 'https://images.pexels.com/photos/594421/pexels-photo-594421.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: true,
    upcoming: false
  },
  {
    id: 2,
    title: 'Spider-Man: Across the Spider-Verse',
    description: 'Miles Morales catapults across the Multiverse, where he encounters a team of Spider-People charged with protecting its very existence. When the heroes clash on how to handle a new threat, Miles must redefine what it means to be a hero.',
    poster: 'https://images.pexels.com/photos/9754/mountains-clouds-forest-fog.jpg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/2486168/pexels-photo-2486168.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.7,
    year: 2023,
    duration: 140,
    genres: ['Animation', 'Action', 'Adventure'],
    director: 'Joaquim Dos Santos',
    writer: 'Phil Lord',
    cast: [
      {
        name: 'Shameik Moore',
        character: 'Miles Morales (voice)',
        image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Hailee Steinfeld',
        character: 'Gwen Stacy (voice)',
        image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Oscar Isaac',
        character: 'Miguel O\'Hara (voice)',
        image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Jake Johnson',
        character: 'Peter B. Parker (voice)',
        image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: true,
    upcoming: false
  },
  {
    id: 3,
    title: 'The Flash',
    description: 'Barry Allen uses his super speed to change the past, but his attempt to save his family creates a world without super heroes, forcing him to race for his life in order to save the future.',
    poster: 'https://images.pexels.com/photos/1608081/pexels-photo-1608081.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/319930/pexels-photo-319930.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 7.0,
    year: 2023,
    duration: 144,
    genres: ['Action', 'Adventure', 'Sci-Fi'],
    director: 'Andy Muschietti',
    writer: 'Christina Hodson',
    cast: [
      {
        name: 'Ezra Miller',
        character: 'Barry Allen / The Flash',
        image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Michael Keaton',
        character: 'Bruce Wayne / Batman',
        image: 'https://images.pexels.com/photos/2406949/pexels-photo-2406949.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Sasha Calle',
        character: 'Kara Zor-El / Supergirl',
        image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  },
  {
    id: 4,
    title: 'Transformers: Rise of the Beasts',
    description: 'When a new threat capable of destroying the entire planet emerges, Optimus Prime and the Autobots must team up with a powerful faction known as the Maximals. With the fate of humanity hanging in the balance, humans Noah and Elena will do whatever it takes to help the Transformers as they engage in the ultimate battle to save Earth.',
    poster: 'https://images.pexels.com/photos/3131971/pexels-photo-3131971.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/924824/pexels-photo-924824.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 6.1,
    year: 2023,
    duration: 127,
    genres: ['Action', 'Adventure', 'Sci-Fi'],
    director: 'Steven Caple Jr.',
    writer: 'Joby Harold',
    cast: [
      {
        name: 'Anthony Ramos',
        character: 'Noah Diaz',
        image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Dominique Fishback',
        character: 'Elena Wallace',
        image: 'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Peter Cullen',
        character: 'Optimus Prime (voice)',
        image: 'https://images.pexels.com/photos/1080243/pexels-photo-1080243.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: true,
    upcoming: false
  },
  {
    id: 5,
    title: 'The Marvels',
    description: 'Carol Danvers, aka Captain Marvel, has reclaimed her identity from the tyrannical Kree and taken revenge on the Supreme Intelligence. But unintended consequences see Carol shouldering the burden of a destabilized universe.',
    poster: 'https://images.pexels.com/photos/4046718/pexels-photo-4046718.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 6.5,
    year: 2023,
    duration: 105,
    genres: ['Action', 'Adventure', 'Fantasy'],
    director: 'Nia DaCosta',
    writer: 'Megan McDonnell',
    cast: [
      {
        name: 'Brie Larson',
        character: 'Carol Danvers / Captain Marvel',
        image: 'https://images.pexels.com/photos/2682452/pexels-photo-2682452.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Iman Vellani',
        character: 'Kamala Khan / Ms. Marvel',
        image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Teyonah Parris',
        character: 'Monica Rambeau',
        image: 'https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: true
  },
  {
    id: 6,
    title: 'Dune: Part Two',
    description: 'Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a path of revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the known universe, he endeavors to prevent a terrible future only he can foresee.',
    poster: 'https://images.pexels.com/photos/1809644/pexels-photo-1809644.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/631477/pexels-photo-631477.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.7,
    year: 2024,
    duration: 166,
    genres: ['Adventure', 'Drama', 'Sci-Fi'],
    director: 'Denis Villeneuve',
    writer: 'Jon Spaihts',
    cast: [
      {
        name: 'Timothée Chalamet',
        character: 'Paul Atreides',
        image: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Zendaya',
        character: 'Chani',
        image: 'https://images.pexels.com/photos/1580271/pexels-photo-1580271.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Rebecca Ferguson',
        character: 'Lady Jessica',
        image: 'https://images.pexels.com/photos/2104252/pexels-photo-2104252.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: true,
    upcoming: false
  },
  {
    id: 7,
    title: 'Oppenheimer',
    description: 'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.',
    poster: 'https://images.pexels.com/photos/6985003/pexels-photo-6985003.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/1119972/pexels-photo-1119972.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.9,
    year: 2023,
    duration: 180,
    genres: ['Biography', 'Drama', 'History'],
    director: 'Christopher Nolan',
    writer: 'Christopher Nolan',
    cast: [
      {
        name: 'Cillian Murphy',
        character: 'J. Robert Oppenheimer',
        image: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Emily Blunt',
        character: 'Katherine Oppenheimer',
        image: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Robert Downey Jr.',
        character: 'Lewis Strauss',
        image: 'https://images.pexels.com/photos/432059/pexels-photo-432059.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  },
  {
    id: 8,
    title: 'Mission: Impossible - Dead Reckoning',
    description: 'Ethan Hunt and his IMF team must track down a dangerous weapon before it falls into the wrong hands.',
    poster: 'https://images.pexels.com/photos/1115238/pexels-photo-1115238.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/670061/pexels-photo-670061.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.2,
    year: 2023,
    duration: 163,
    genres: ['Action', 'Adventure', 'Thriller'],
    director: 'Christopher McQuarrie',
    writer: 'Christopher McQuarrie',
    cast: [
      {
        name: 'Tom Cruise',
        character: 'Ethan Hunt',
        image: 'https://images.pexels.com/photos/1121796/pexels-photo-1121796.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Hayley Atwell',
        character: 'Grace',
        image: 'https://images.pexels.com/photos/1081685/pexels-photo-1081685.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Ving Rhames',
        character: 'Luther Stickell',
        image: 'https://images.pexels.com/photos/937481/pexels-photo-937481.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: true,
    upcoming: false
  },
  {
    id: 9,
    title: 'The Marvels',
    description: 'Carol Danvers gets her powers entangled with those of Kamala Khan and Monica Rambeau, forcing them to work together to save the universe.',
    poster: 'https://images.pexels.com/photos/4048434/pexels-photo-4048434.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.1,
    year: 2023,
    duration: 105,
    genres: ['Action', 'Adventure', 'Fantasy'],
    director: 'Nia DaCosta',
    writer: 'Megan McDonnell',
    cast: [
      {
        name: 'Brie Larson',
        character: 'Carol Danvers / Captain Marvel',
        image: 'https://images.pexels.com/photos/2682452/pexels-photo-2682452.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Iman Vellani',
        character: 'Kamala Khan / Ms. Marvel',
        image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Teyonah Parris',
        character: 'Monica Rambeau',
        image: 'https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: true
  },
  {
    id: 10,
    title: 'Ant-Man and the Wasp: Quantumania',
    description: 'Scott Lang and Hope Van Dyne, along with Hank Pym and Janet Van Dyne, explore the Quantum Realm, where they interact with strange creatures and embark on an adventure that goes beyond the limits of what they thought was possible.',
    poster: 'https://images.pexels.com/photos/1826764/pexels-photo-1826764.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/3648269/pexels-photo-3648269.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 6.4,
    year: 2023,
    duration: 125,
    genres: ['Action', 'Adventure', 'Comedy'],
    director: 'Peyton Reed',
    writer: 'Jeff Loveness',
    cast: [
      {
        name: 'Paul Rudd',
        character: 'Scott Lang / Ant-Man',
        image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Evangeline Lilly',
        character: 'Hope van Dyne / The Wasp',
        image: 'https://images.pexels.com/photos/2804282/pexels-photo-2804282.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Jonathan Majors',
        character: 'Kang the Conqueror',
        image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  },
  {
    id: 11,
    title: 'The Equalizer 3',
    description: 'Robert McCall finds himself at home in Southern Italy but he discovers his friends are under the control of local crime bosses. As events turn deadly, McCall knows what he has to do: become his friends\' protector by taking on the mafia.',
    poster: 'https://images.pexels.com/photos/1525041/pexels-photo-1525041.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/5312581/pexels-photo-5312581.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 6.9,
    year: 2023,
    duration: 109,
    genres: ['Action', 'Crime', 'Thriller'],
    director: 'Antoine Fuqua',
    writer: 'Richard Wenk',
    cast: [
      {
        name: 'Denzel Washington',
        character: 'Robert McCall',
        image: 'https://images.pexels.com/photos/1304647/pexels-photo-1304647.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Dakota Fanning',
        character: 'Emma Collins',
        image: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  },
  {
    id: 12,
    title: 'Aquaman and the Lost Kingdom',
    description: 'When an ancient power is unleashed, Aquaman must forge an uneasy alliance with an unlikely ally to protect Atlantis, and the world, from irreversible devastation.',
    poster: 'https://images.pexels.com/photos/1535162/pexels-photo-1535162.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/3894857/pexels-photo-3894857.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.2,
    year: 2023,
    duration: 115,
    genres: ['Action', 'Adventure', 'Fantasy'],
    director: 'James Wan',
    writer: 'David Leslie',
    cast: [
      {
        name: 'Jason Momoa',
        character: 'Arthur Curry / Aquaman',
        image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Amber Heard',
        character: 'Mera',
        image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Patrick Wilson',
        character: 'Orm Marius',
        image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: true
  },
  {
    id: 13,
    title: 'Avengers: Endgame',
    description: 'After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos\' actions and restore balance to the universe.',
    poster: 'https://images.pexels.com/photos/1724888/pexels-photo-1724888.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/956999/milky-way-starry-sky-night-sky-star-956999.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 8.4,
    year: 2019,
    duration: 181,
    genres: ['Action', 'Adventure', 'Drama'],
    director: 'Anthony Russo, Joe Russo',
    writer: 'Christopher Markus, Stephen McFeely',
    cast: [
      {
        name: 'Robert Downey Jr.',
        character: 'Tony Stark / Iron Man',
        image: 'https://images.pexels.com/photos/1680175/pexels-photo-1680175.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Chris Evans',
        character: 'Steve Rogers / Captain America',
        image: 'https://images.pexels.com/photos/697509/pexels-photo-697509.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Mark Ruffalo',
        character: 'Bruce Banner / Hulk',
        image: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  },
  {
    id: 14,
    title: 'The Expendables 4',
    description: 'A new generation of stars join the world\'s top action stars for an adrenaline-fueled adventure in The Expendables 4.',
    poster: 'https://images.pexels.com/photos/1270184/pexels-photo-1270184.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/351774/pexels-photo-351774.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 7.9,
    year: 2023,
    duration: 110,
    genres: ['Action', 'Adventure', 'Thriller'],
    director: 'Scott Waugh',
    writer: 'Spenser Cohen',
    cast: [
      {
        name: 'Jason Statham',
        character: 'Lee Christmas',
        image: 'https://images.pexels.com/photos/1496647/pexels-photo-1496647.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Sylvester Stallone',
        character: 'Barney Ross',
        image: 'https://images.pexels.com/photos/594421/pexels-photo-594421.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Dolph Lundgren',
        character: 'Gunner Jensen',
        image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: true
  },
  {
    id: 15,
    title: 'Blue Beetle',
    description: 'A Mexican teenager finds an alien beetle that gives him superpowered armor. When the mysterious Kord Industries seeks it, the teenager becomes the Blue Beetle.',
    poster: 'https://images.pexels.com/photos/1983037/pexels-photo-1983037.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/7233354/pexels-photo-7233354.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 7.0,
    year: 2023,
    duration: 128,
    genres: ['Action', 'Adventure', 'Sci-Fi'],
    director: 'Angel Manuel Soto',
    writer: 'Gareth Dunnet-Alcocer',
    cast: [
      {
        name: 'Xolo Maridueña',
        character: 'Jaime Reyes / Blue Beetle',
        image: 'https://images.pexels.com/photos/2698938/pexels-photo-2698938.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Bruna Marquezine',
        character: 'Jenny Kord',
        image: 'https://images.pexels.com/photos/1197132/pexels-photo-1197132.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Becky G',
        character: 'Khaji-Da (voice)',
        image: 'https://images.pexels.com/photos/1310522/pexels-photo-1310522.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  },
  {
    id: 16,
    title: 'Fast X',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
    poster: 'https://images.pexels.com/photos/3422964/pexels-photo-3422964.jpeg?auto=compress&cs=tinysrgb&w=600',
    backdrop: 'https://images.pexels.com/photos/1545743/pexels-photo-1545743.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    rating: 5.8,
    year: 2023,
    duration: 141,
    genres: ['Action', 'Crime', 'Thriller'],
    director: 'Louis Leterrier',
    writer: 'Dan Mazeau',
    cast: [
      {
        name: 'Vin Diesel',
        character: 'Dominic Toretto',
        image: 'https://images.pexels.com/photos/594421/pexels-photo-594421.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Jason Momoa',
        character: 'Dante Reyes',
        image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=600'
      },
      {
        name: 'Michelle Rodriguez',
        character: 'Letty Ortiz',
        image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600'
      }
    ],
    trending: false,
    upcoming: false
  }
];