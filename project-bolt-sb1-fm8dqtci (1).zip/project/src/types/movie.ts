export interface Cast {
  name: string;
  character: string;
  image: string;
}

export interface Movie {
  id: number;
  title: string;
  description: string;
  poster: string;
  backdrop: string;
  rating: number;
  year: number;
  duration: number;
  genres: string[];
  director: string;
  writer: string;
  cast: Cast[];
  trending: boolean;
  upcoming: boolean;
}